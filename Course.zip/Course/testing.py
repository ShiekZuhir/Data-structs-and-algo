A = [1,2,4,5,6,7,8,9]
gap = len(A)//2
def ShellSort(A):
    while gap > 1:
        for i in range(gap, len(A))


