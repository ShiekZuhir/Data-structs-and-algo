'''Write a function that returns the sum of the first n numbers of the Fibonacci
sequence (Wikipedia). The first 2 numbers in the sequence are 1,1, …
'''


def fibonacci(n):
        if n <= 0: return 0
        a = 1
        b = 1
        total = 0
        for i in range(n):
            a + int(total)
            total += a
            after = a + b
            a = b
            b = after
        return total
print(fibonacci(5))



"""def fibonacci(n):
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fibonacci(n-1) + fibonacci(n-2)
"""