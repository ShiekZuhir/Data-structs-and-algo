"""Take the two sorted arrays A and B from Question 1 above and merge into a new
array C. You must do this in linear time. Note that the size of C must be size of A
plus size of B. Use the merging technique used in Merge Sort"""
import random

A = [random.randint(0, 1024) for i in range(256)]
B = [random.randint(0, 1024) for j in range(256)]

def mergesort(A, B):
    C = [0] * (len(A) + len(B))
    i = 0 # pointer for A
    j = 0 # pointer for B
    k = 0 # pointer for C

    while i < len(A) and j < len(B):
        if A[i] < B[j]:
            C[k] = A[i]
            i += 1
        else:
            C[k] = B[j]
            j += 1
        k += 1
    while i < len(A):
        C[k] = A[i]
        i += 1
        k += 1
    while j < len(B):
        C[k] = B[j]
        j += 1
        k += 1
    return C



print(mergesort( [1,4,7,9],[2,3,6,8]))



