"""Write a program that generates the Collatz sequence of all the integers in the range
2 to 512. The program will store the generated sequences in a CSV file.
See The Simplest Math Problem No One Can Solve - Collatz Conjecture - YouTube"""
import csv

def collatz(integer):
    sequence = [integer]
    while integer != 1:
        if integer % 2 == 0:
            integer = integer // 2
        else:
            integer = integer * 3 + 1
        sequence.append(int(integer))
    return sequence
def csvfile():
    with open('collatz.csv', 'w', newline='') as f:
        writer = csv.writer(f)
        for integer in range(2,513): # since range takes from 2 up to but not including 512 I needed to make it 513
            row = collatz(integer)
            writer.writerow(row)

csvfile()