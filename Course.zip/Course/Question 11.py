"""Write a function that computes cosine or sine by taking the first n terms of the
appropriate (Maclaurin?) series expansion. Be careful with computing large
factorials."""

def factorial(n):
    if n == 0:
        return 1
    else:
        return n * factorial(n-1)

def cosine(x,n_terms):
    total = 0
    for i in range(0,n_terms):
        numerator = x ** (2*i)
        denominator = factorial(2*i)
        sign = (-1) ** i
        total += sign * numerator / denominator
    return total
print(cosine(0,10))