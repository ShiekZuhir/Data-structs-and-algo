"""Write a program that uses an ADT Stack to evaluate arithmetic expressions in RPN
format. The contents of the stack should be displayed on the screen during
evaluation. The allowed arithmetic operators are +, -, x, and /."""
from inspect import stack
from os.path import split


class Stack:
    def __init__(self):
        self.items = []

    def is_empty(self):

        return self.items == []

    def push(self, item):
        self.items.append(item)

    def pop(self):

        if self.is_empty():
            raise IndexError("pop form empty stack")
        return self.items.pop()

    def peek(self):
        if self.is_empty():
            raise IndexError("peek form empty stack")
        return self.items[-1]

    def evaluateRNP(expression):
        tokens = expression.split()
        stack = Stack()
        for token in tokens:
            print(token)
            if token.isnumeric():
                stack.push(int(token))
            elif token in ["+", "-", "x", "/"]:
                b = stack.pop()
                a = stack().pop()
            if 
            stack.push(result)
        return stack.pop()


