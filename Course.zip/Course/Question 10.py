#Write a recursive function
#that finds the largest number in a given list of integers
list_of_integers = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
def maxrecursion(a):
    if len(a) == 1: #BC, if list have only one number lef it needs to be maximum,
        return a[0] # so stop here and return it.
    else:
        max_rec = maxrecursion(a[1:]) #a[1:] is a slice, keeps cutting the list until it's empty.
        if a[0] > max_rec:
            return a[0]
        else:
            return max_rec
print(maxrecursion(list_of_integers))


"""
basically the program runs untill the only remains one number left in
the list but that number has to be the maximum though!
if len(a) == 1 is a base case keeps counting the list until it reaches 1 if it equals 1 then program ends and prints that max number.
a[0] is the first number 
max_rec = maxrecursion(a[1:]) #a[1:] is a slice, keeps cutting the list until it's empty.
        if a[0] > max_rec:
            return a[0]
        else:
            return max_rec 
a[1:] slices the list everytime it loops back dreasing the number each loop.
#[0] keeps chang
"""