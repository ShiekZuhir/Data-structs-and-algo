"""Write a program that finds an approximation to the square root of a given number
n using an iterative numerical method such as the Newton-Raphson Method."""

def sqrt(n):
    guess = n / 2
    while True:
        new_guess = (guess + n / guess) / 2
        if abs(new_guess - guess) < 0.00001:
            return new_guess
        guess = new_guess
n = 25
print(sqrt(n))

# basically what we need to do is to start with an intiAl guess X(0)
# then we need to compute the next x value which is X(1)
# then X(2)
"""
1.def sqrt(n) we are defing a function called sqrt
2. guess = n / 2 ,  every search needs a starting line if you are starting with 25, 
computers first gues is 12.5 wrong but it's something to start with.
3. while True: new_guess = (guess + n / guess) / 2





"""