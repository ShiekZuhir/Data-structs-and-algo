"""Take the two sorted arrays A and B from Question 1 above and merge into a new
array C. You must do this in linear time. Note that the size of C must be size of A
plus size of B. Use the merging technique used in Merge Sort"""
import random

A = [random.randint(0, 1024) for i in range(256)]
B = [random.randint(0, 1024) for j in range(256)]

def shellsort(arr):
    gap = len(arr) // 2
    while gap > 0:
        for i in range ( gap,len(arr)):
            temp = arr[i]
            j = i
            while j >= gap and arr[j-gap] > temp:
                arr[j] = arr[j-gap]
                j -= gap
            arr[j] = temp
        gap = gap // 2
    return arr

def quicksort(arr, low, high):
    if  low < high:
            pivot_index  = partition(arr,low ,high)
            quicksort(arr,low,pivot_index - 1)
            quicksort(arr,pivot_index + 1, high)

def partition(arr,low,high):
    pivot = arr[high]
    i = low - 1
    for j in range (low, high):
        if arr[j] <= pivot:
            i = i + 1
            arr[i],arr[j] = arr[j],arr[i]
    arr[i+1], arr[high] = arr[high],arr[i+1]
    return i + 1

def mergesort(A, B):
    C = [0] * (len(A) + len(B))
    i = 0 # pointer for A
    j = 0 # pointer for B
    k = 0 # pointer for C

    while i < len(A) and j < len(B):
        if A[i] < B[j]:
            C[k] = A[i]
            i += 1
        else:
            C[k] = B[j]
            j += 1
        k += 1
    while i < len(A):
        C[k] = A[i]
        i += 1
        k += 1
    while j < len(B):
        C[k] = B[j]
        j += 1
        k += 1
    return C

if __name__ == "__main__":
    A = shellsort(A)
    quicksort(B, 0, len(B) - 1)
    C = mergesort(A, B)
    print(C)
