'''Create two integer arrays A and B. The two arrays must contain at least 256
elements but must be of unequal size. Populate both arrays with randomly
generated integers between 0 and 1024. Sort array A using Shell Sort and array B
using Quick Sort '''
import random
A = [random.randint(0, 1024) for i in range(256)]
B = [random.randint(0, 1024) for j in range(256)]

def shellsort(arr):
    gap = len(arr) // 2
    while gap > 0:
        for i in range ( gap,len(arr)):
            temp = arr[i]
            j = i
            while j >= gap and arr[j-gap] > temp:
                arr[j] = arr[j-gap]
                j -= gap
            arr[j] = temp
        gap = gap // 2
    return arr


def quicksort(arr, low, high):
    if  low < high:
            pivot_index  = partition(arr,low ,high)
            quicksort(arr,low,pivot_index - 1)
            quicksort(arr,pivot_index + 1, high)

def partition(arr,low,high):
    pivot = arr[high]
    i = low - 1
    for j in range (low, high):
        if arr[j] <= pivot:
            i = i + 1
            arr[i],arr[j] = arr[j],arr[i]
    arr[i+1], arr[high] = arr[high],arr[i+1]
    return i + 1

if __name__ == '__main__':
    A = shellsort(A)
    quicksort(B, 0 , len(B) - 1)
    C = merges
    print(A)
    print(B)