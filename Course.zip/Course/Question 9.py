"""Write a program that, given an array of integers, finds all integers in the array that
are repeated more than once. Try to find a fast and memory-efficient way of doing
this"""
arr_of_ints = [1,2,2,9,3,4,7,5,6,7,8,9,10] # 2,9,7
dic_of_ints = {1: 1, 2: 2, 3: 1 , 4: 1, 5: 1, 6: 1, 7: 2, 8: 1, 9: 2}

def repeatedints(arr):
    counts = {}
    for num in arr:
        counts[num] = counts.get(num, 0) + 1 # get the current count of num or 0 if it doesn't exist yet the add 1.
    for key in counts:
        if counts[key] > 1:
            print(key)
print(repeatedints(arr_of_ints))
