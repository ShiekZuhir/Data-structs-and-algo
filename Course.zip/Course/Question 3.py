"""Let A be an array of n distinct elements (that is, the elements of A are A[0], . . . ,
A[n−1] with no duplicates). An element A[i] is called extreme if the following
conditions hold regarding A[i].
• A[i] is not the first nor the last element of A. That is, 0 < i < n – 1 and either A[i
− 1] < A[i] > A[i + 1] or A[i − 1] > A[i] < A[i + 1]. For example, the extreme
points of an array [0, 5, 3, 6, 8, 7, 15, 9] are 5, 3, 8, 7, 15.
Write an algorithm that prints the extreme points of the given array. If there are no
extreme points, the algorithm prints “SORTED”. Do you agree that an array has no
extreme points if and only if it is sorted? Explain your answer."""
#A[i-1] < A[i] > A[i+1] local Max
#A[i-1] > A[i] < A[i+1] local Mini

def extreme_points(A):
    found = False
    for i in range (1,len(A) - 1):
        if A[i-1] < A[i] > A[i + 1]: # local Max
            print(A[i])
            found = True
        elif A[i-1] > A[i] < A[i + 1]: # local Minimum
            print(A[i])
            found = True
    if not found:
        print("SORTED")

print(extreme_points([0, 5, 3, 6, 8, 7, 15, 9]))

 ##########################-----############################################------############

#sorted in this case means [1,2,3,4,5,6,...]

""""
With distinct elements, if there are no extreme points, the array must be sorted 
either ascending or descending.Because if it ever changes direction, that turning point
would be an extreme point.
so the answer is yes professor

"""