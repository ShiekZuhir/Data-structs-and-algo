"""Write a Boolean function that checks if a number is prime. Also implement the
Sieve of Eratosthenes algorithm – two separate algorithms. Explain any
optimizations made"""

from math import sqrt

#function checks if number is prime:
def isprimenumber(n):
    if n < 2:
        return False
    for i in range(2,int(sqrt(n)) + 1):
        if n % i == 0:
            return False
    return True

def sieve(limit):
    primes = [True] * (limit + 1)
    primes[0] = False
    primes[1] = False
    for i in range(2,int(sqrt(limit))):
        if primes[i]:
            for j in range(i*i, limit+1, i):
                primes[j] = False
    return primes

print(isprimenumber(17))
print([i for i in range(20) if sieve(20)[i]])